PolarLabs QR Studio v1.0.0 — Windows ARM64

Gratuito e open source (MIT).
Estrarre il contenuto dello ZIP e avviare PolarLabs-QR-Studio.exe.

L'eseguibile è stato compilato per Windows 11 ARM64, per esempio Microsoft Surface ARM.
Non è destinato a Windows x64 e non è firmato digitalmente.

Alcune installazioni Windows potrebbero bloccare file non firmati per motivi di
sicurezza. Non disattivare Smart App Control, SmartScreen o policy aziendali;
in quel caso usare il codice sorgente e Python nativo ARM64 (vedi repository).

Codice sorgente, istruzioni e changelog:
https://github.com/PolarLabs-OSS/PolarLabs-QR-Studio

© 2026 Space Services SRLS / PolarLabs. MIT License.
